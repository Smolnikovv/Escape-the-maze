using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

public class PlayerMovement : MonoBehaviour
{
    public GameObject player;

    private Vector3 positon = new Vector3();
    private FileStream fs;
    private float time = 0;
    private void Start()
    {
        if (Directory.Exists(@"ValidateLogs"))
        { }
        else
        {
            DirectoryInfo di = Directory.CreateDirectory(@"ValidateLogs");
        }
        fs = File.Create(@"ValidateLogs\Run" + DateTime.Now);
    }
    void Update()
    {
        positon = GameObject.Find(player.name).transform.position;
        time += Time.deltaTime;
        AddText(fs, time.ToString() + " " + positon.ToString());
    }
    private static void AddText(FileStream fs, string value)
    {
        File.AppendAllText(fs.ToString(), value + Environment.NewLine);
    }
}
